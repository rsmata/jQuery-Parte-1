﻿
var tempoInicial =  $("#tempo-digitacao").text();
var campo = $(".campo-digitacao");

$(function(){
    atualizaTamanhoFrase();
    inicializaMarcadores();
    inicializaContadores();
    inicializaCronometro();
    $("#botao-reiniciar").click(reiniciaJogo);
});


function atualizaTamanhoFrase(){
    var frase = $(".frase").text();
    var numPalavras = frase.split(/\S+/).length - 1;

    var tamanahoFrase = $("#tamanho-frase");
    tamanahoFrase.text(numPalavras);
}

function inicializaMarcadores(){
    var frase = $(".frase").text();
    campo.on("input", function(){
        var digitado = campo.val();

        if(frase.startsWith(digitado)){
            campo.addClass("borda-verde");
            campo.removeClass("borda-vermelha");
        }
        else{
            campo.removeClass("borda-verde");
            campo.addClass("borda-vermelha");
        }
    });
}

function inicializaContadores(){
    campo.on("input", function(){
        
        var conteudo = campo.val();
        var quantidadePalavras = conteudo.split(/\S+/).length - 1;
        var quantidadeCaracteres = conteudo.length;

        if(campo.length < 1)
        {
            quantidadeCaracteres = 0;
            quantidadePalavras = 0;
        }

        $("#contador-palavras").text(quantidadePalavras);
        $("#contador-caracteres").text(quantidadeCaracteres);
    });
}


function inicializaCronometro() {
    var tempoRestante = $("#tempo-digitacao").text();
    $("#botao-reiniciar").attr("disabled", true);
    campo.one("focus", function(){
        
        var idSetInterval = setInterval(function(){
            tempoRestante = tempoRestante - 1;
            $("#tempo-digitacao").text(tempoRestante);
            
            if(tempoRestante < 1){
                campo.attr("disabled", true);
                clearInterval(idSetInterval);
                campo.toggleClass("campo-desativado");
                $("#botao-reiniciar").attr("disabled", false);
            }
        }, 1000);
    });
}

function reiniciaJogo(){
    campo.attr("disabled", false);
    campo.toggleClass("campo-desativado");
    campo.val("");
    
    $("#tempo-digitacao").text(tempoInicial);
    $("#contador-palavras").text("0");
    $("#contador-caracteres").text("0");
    
    campo.removeClass("");
    campo.removeClass("");

    inicializaCronometro();
};