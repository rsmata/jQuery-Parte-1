﻿var frase = $(".frase").text();
var numPalavras = frase.split(/\S+/).length;
console.log(numPalavras);

var tamanahoFrase = $("#tamanho-frase");
tamanahoFrase.text(numPalavras);

var campo = $(".campo-digitacao");
campo.on("input", function(){
    var conteudo = campo.val();
    var quantidadePalavras = conteudo.split(/\S+/).length - 1;
    var quantidadeCaracteres = conteudo.length;

    $("#contador-palavras").text(quantidadePalavras);
    $("#contador-caracteres").text(quantidadeCaracteres);
});