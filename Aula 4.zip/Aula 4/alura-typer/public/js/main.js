﻿
var tempoInicial =  $("#tempo-digitacao").text();
var campo = $(".campo-digitacao");
var idSetInterval = 0;


$(function(){
    atualizaTamanhoFrase();
    inicializaContadores();
    inicializaCronometro();
    $("#botao-reiniciar").click(reiniciaJogo);
});


function atualizaTamanhoFrase(){
    var frase = $(".frase").text();
    var numPalavras = frase.split(/\S+/).length - 1;

    var tamanahoFrase = $("#tamanho-frase");
    tamanahoFrase.text(numPalavras);
}

function inicializaContadores(){
    campo.on("input", function(){
        var conteudo = campo.val();
        var quantidadePalavras = conteudo.split(/\S+/).length - 1;
        var quantidadeCaracteres = conteudo.length;

        if(campo.length < 1)
        {
            quantidadeCaracteres = 0;
            quantidadePalavras = 0;
        }

        $("#contador-palavras").text(quantidadePalavras);
        $("#contador-caracteres").text(quantidadeCaracteres);
    });
}


function inicializaCronometro() {
    var tempoRestante = $("#tempo-digitacao").text();

    campo.one("focus", function(){
        
        idSetInterval = setInterval(function(){
            tempoRestante = tempoRestante - 1;
            $("#tempo-digitacao").text(tempoRestante);
            
            if(tempoRestante == 0){
                campo.attr("disabled", true);
                clearInterval(idSetInterval);
            }
        }, 1000);
    });
}

function reiniciaJogo(){
    campo.attr("disabled", false);
    campo.val("");
    
    $("#tempo-digitacao").text(tempoInicial);

    $("#contador-palavras").text("0");
    $("#contador-caracteres").text("0");

    inicializaCronometro();

    clearInterval(idSetInterval);
};