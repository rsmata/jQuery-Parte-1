﻿var frase = $(".frase").text();
var numPalavras = frase.split(" ").length;
console.log(numPalavras);

var tamanahoFrase = $("#tamanho-frase");
tamanahoFrase.text(numPalavras);