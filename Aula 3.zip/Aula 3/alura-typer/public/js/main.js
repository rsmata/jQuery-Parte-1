﻿var frase = $(".frase").text();
var numPalavras = frase.split(/\S+/).length;
console.log(numPalavras);

var tamanahoFrase = $("#tamanho-frase");
tamanahoFrase.text(numPalavras);

var campo = $(".campo-digitacao");
campo.on("input", function(){
    var conteudo = campo.val();
    var quantidadePalavras = conteudo.split(/\S+/).length - 1;
    var quantidadeCaracteres = conteudo.length;

    $("#contador-palavras").text(quantidadePalavras);
    $("#contador-caracteres").text(quantidadeCaracteres);
});

var tempoRestante = $("#tempo-digitacao").text();
campo.one("focus", function(){
    
    var idSetInterval = setInterval(function(){
        tempoRestante = tempoRestante - 1;
        $("#tempo-digitacao").text(tempoRestante);
        
        if(tempoRestante == 0){
            campo.attr("disabled", true);
            clearInterval(idSetInterval);
        }
    }, 1000);
});